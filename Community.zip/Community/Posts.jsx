 

import React, { useState } from "react";
import './Posts.css?v=1.0.1'; // Update version as needed
import farmer from "../../assets/farmer.png";
import farmer2 from "../../assets/farmer2.png";

// Modal for creating a post
const PostModal = ({ show, onClose, onCreatePost }) => {
  const [content, setContent] = useState("");
  const [postType, setPostType] = useState("General");
  const [media, setMedia] = useState("");

  if (!show) return null;

  const handlePost = () => {
    if (!content && !media) return; // Prevent empty posts
    onCreatePost({
      user: "Srinu",
      avatar:  farmer,
      content,
      postType,
      createdAt: new Date().toLocaleString(),
      media,
    });
    setContent("");
    setPostType("General");
    setMedia("");
    onClose();
  };

  const handleMediaUpload = (e) => {
    setMedia(URL.createObjectURL(e.target.files[0]));
  };

  return (
    <div className="modal-background">
      <div className="modal-container">
        <h2 className="modal-header">Create a Post</h2>
        <textarea
          placeholder="What do you want to talk about?"
          className="modal-textarea"
          value={content}
          onChange={(e) => setContent(e.target.value)}
        ></textarea>

        <label htmlFor="media-upload" className="upload-icon">+</label>
        <input
          type="file"
          id="media-upload"
          style={{ display: "none" }}
          onChange={handleMediaUpload}
        />
        <div className="modal-footer">
          <button className="modal-cancel-button" onClick={onClose}>Cancel</button>
          <select
            className="post-type-dropdown"
            value={postType}
            onChange={(e) => setPostType(e.target.value)}
          >
            <option value="General">General</option>
            <option value="Problem">Problem</option>
          </select>
          <button className="modal-button" onClick={handlePost}>Post</button>
        </div>
      </div>
    </div>
  );
};

// Comment section component
const CommentSection = () => {
  const [comments, setComments] = useState([
    { user: "Devender", role: "Agriculture Expert", content: "Great work!", likes: 1 },
    { user: "Ramesh", role: "Agriculture Student", content: "Interesting post!", likes: 0 },
  ]);
  const [newComment, setNewComment] = useState("");

  const handleAddComment = () => {
    if (!newComment) return;
    setComments([
      ...comments,
      { user: "Current User", role: "Role", content: newComment, likes: 0 },
    ]);
    setNewComment("");
  };

  const handleLike = (index) => {
    const updatedComments = [...comments];
    updatedComments[index].likes += 1;
    setComments(updatedComments);
  };

  return (
    <div className="comment-section">
      {comments.map((comment, index) => (
        <div key={index} className="comment">
          {/* <img src="user-avatar.jpg" alt="User" className="comment-avatar" /> */}
                  <img src={farmer2} alt="User" className="comment-avatar" />
          <div className="comment-content">
            <strong>{comment.user}</strong> <span className="comment-role">{comment.role}</span>
            <p>{comment.content}</p>
            <button onClick={() => handleLike(index)} className="comment-like-button">
              Like ({comment.likes})
            </button>
          </div>
        </div>
      ))}
      <div className="add-comment">
        <img src={farmer} alt="User" className="comment-avatar" />
        <input
          type="text"
          className="comment-input"
          placeholder="Add a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
        />
        <button onClick={handleAddComment} className="comment-submit">Post</button>
      </div>
    </div>
  );
};

// Post component to display individual posts
const Post = ({ user, avatar, content, postType, createdAt, media }) => {
  const [showComments, setShowComments] = useState(false);
  const headerClass = postType === "Problem" ? "header-problem" : "header-general";

  return (
    <div className="post-container">
      <div className={`post-header ${headerClass}`}>
        <img src={avatar} alt="Avatar" className="user-avatar" />
        <div>
          <h3>{user}</h3>
          <span>{createdAt}</span>
        </div>
      </div>
      <p className="post-content">{content}</p>
      {media && <img src={media} alt="Media" className="post-media" />}
      <div className="post-footer">
        <button className="post-action">Like</button>
        <button className="post-action" onClick={() => setShowComments(!showComments)}>Comment</button>
        <button className="post-action">Save</button>
      </div>
      {showComments && <CommentSection />}
    </div>
  );
};

// Main Posts component to handle state
const Posts = () => {
  const [posts, setPosts] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const addPost = (post) => {
    setPosts([post, ...posts]);
  };

  return (
    <div className="posts-page-container">
      <div className="posts-container" style={{ position: "relative" }}>
        {posts.map((post, index) => (
          <Post key={index} {...post} />
        ))}

        <div className="sticky-bar">
          <input
            placeholder="Create a post..."
            className="sticky-input"
            onClick={() => setShowModal(true)}
          />
        </div>

        <PostModal show={showModal} onClose={() => setShowModal(false)} onCreatePost={addPost} />
      </div>

      {/* Added photo */}
      <div className="Profile-Right">
      <p className="post-tagline">Growing Together: Your Agricultural Community Hub</p>
          <div className="post-media-container">
            {/* Image will be added as a background in CSS */}
          </div>
      </div>
     
    </div>
  );
};

export default Posts;

